from solution import climb_stairs

if __name__ == "__main__":
    n = int(input())
    print(climb_stairs(n))
